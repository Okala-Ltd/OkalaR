#' @keywords internal
"_PACKAGE"

#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`

## usethis namespace: start
## usethis namespace: end
NULL
