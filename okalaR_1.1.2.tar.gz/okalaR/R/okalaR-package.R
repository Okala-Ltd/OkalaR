#' okalaR: API wrapper for the Okala dashboard
#'
#' Provides functions to interact with the Okala dashboard API, including project, station, media, and label management.
#'
#' @docType package
#' @name okalaR
NULL
