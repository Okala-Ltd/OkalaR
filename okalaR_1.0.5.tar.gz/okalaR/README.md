# OkalaR
Wrapper around Okala's api
